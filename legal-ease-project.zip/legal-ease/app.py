import os, json, sqlite3
from datetime import datetime
from functools import wraps
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")
DB = "legal_ease.db"

DOCUMENT_TYPES = {
    "rental": "Rental Agreement",
    "employment": "Employment Agreement",
    "loan": "Loan Agreement",
    "affidavit": "Affidavit",
    "nda": "Non-Disclosure Agreement (NDA)",
    "property": "Property Agreement",
    "partnership": "Business Partnership Agreement",
    "notice": "Legal Notice",
}

FIELDS = {
    "rental": [
        ("landlord", "Landlord Name"), ("tenant", "Tenant Name"),
        ("property_address", "Property Address"), ("rent", "Monthly Rent"),
        ("deposit", "Security Deposit"), ("duration", "Agreement Duration"),
        ("start_date", "Start Date"), ("purpose", "Purpose / Use of Property")
    ],
    "employment": [
        ("employer", "Employer / Company Name"), ("employee", "Employee Name"),
        ("job_title", "Job Title"), ("salary", "Salary"),
        ("work_location", "Work Location"), ("start_date", "Start Date"),
        ("duration", "Employment Duration"), ("duties", "Main Duties")
    ],
    "loan": [
        ("lender", "Lender Name"), ("borrower", "Borrower Name"),
        ("amount", "Loan Amount"), ("interest", "Interest Rate"),
        ("repayment", "Repayment Schedule"), ("due_date", "Due Date"),
        ("purpose", "Purpose of Loan"), ("security", "Security / Collateral (if any)")
    ],
    "affidavit": [
        ("deponent", "Deponent Name"), ("address", "Address"),
        ("subject", "Purpose / Subject"), ("facts", "Facts to Declare"),
        ("date", "Date"), ("place", "Place")
    ],
    "nda": [
        ("discloser", "Disclosing Party"), ("recipient", "Receiving Party"),
        ("information", "Confidential Information"), ("purpose", "Permitted Purpose"),
        ("duration", "Confidentiality Duration"), ("exceptions", "Exceptions"),
        ("date", "Effective Date")
    ],
    "property": [
        ("seller", "Seller Name"), ("buyer", "Buyer Name"),
        ("property", "Property Description"), ("price", "Agreed Price"),
        ("payment", "Payment Terms"), ("date", "Agreement Date"),
        ("possession", "Possession Date"), ("documents", "Documents / Records")
    ],
    "partnership": [
        ("partners", "Partner Names"), ("business", "Business Name"),
        ("purpose", "Business Purpose"), ("capital", "Capital Contributions"),
        ("profit", "Profit / Loss Sharing"), ("roles", "Roles and Responsibilities"),
        ("duration", "Partnership Duration"), ("date", "Effective Date")
    ],
    "notice": [
        ("sender", "Sender Name"), ("recipient", "Recipient Name"),
        ("sender_address", "Sender Address"), ("recipient_address", "Recipient Address"),
        ("subject", "Subject"), ("facts", "Facts / Events"),
        ("demand", "Demand / Requested Action"), ("deadline", "Response Deadline")
    ],
}

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        doc_type TEXT NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def generate_with_ai(doc_type, data):
    """Uses OpenAI when OPENAI_API_KEY is configured; otherwise uses a safe template draft."""
    api_key = os.getenv("OPENAI_API_KEY")
    title = DOCUMENT_TYPES[doc_type]

    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            prompt = f"""
Create a clear draft of a {title} using the information below.
This is an educational document-generation application. Do not invent facts,
laws, citations, government forms, legal rights, or penalties. Keep placeholders
for missing information. Use headings and numbered clauses. Do not claim that
the draft is legally valid in every jurisdiction.

User information:
{json.dumps(data, ensure_ascii=False, indent=2)}

Return only the document draft.
"""
            response = client.responses.create(
                model=os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
                input=prompt
            )
            text = response.output_text.strip()
            if text:
                return text
        except Exception as e:
            print("AI generation failed:", e)

    return template_draft(doc_type, data)

def template_draft(doc_type, d):
    title = DOCUMENT_TYPES[doc_type].upper()
    lines = [title, "", "This document is a draft generated from the information provided by the user.", ""]
    labels = {
        "rental": [
            ("Landlord", "landlord"), ("Tenant", "tenant"), ("Property", "property_address"),
            ("Monthly Rent", "rent"), ("Security Deposit", "deposit"), ("Duration", "duration"),
            ("Start Date", "start_date"), ("Purpose", "purpose")
        ],
        "employment": [
            ("Employer", "employer"), ("Employee", "employee"), ("Job Title", "job_title"),
            ("Salary", "salary"), ("Work Location", "work_location"), ("Start Date", "start_date"),
            ("Duration", "duration"), ("Duties", "duties")
        ],
        "loan": [
            ("Lender", "lender"), ("Borrower", "borrower"), ("Loan Amount", "amount"),
            ("Interest Rate", "interest"), ("Repayment", "repayment"), ("Due Date", "due_date"),
            ("Purpose", "purpose"), ("Security / Collateral", "security")
        ],
        "affidavit": [
            ("Deponent", "deponent"), ("Address", "address"), ("Subject", "subject"),
            ("Facts", "facts"), ("Date", "date"), ("Place", "place")
        ],
        "nda": [
            ("Disclosing Party", "discloser"), ("Receiving Party", "recipient"),
            ("Confidential Information", "information"), ("Permitted Purpose", "purpose"),
            ("Confidentiality Duration", "duration"), ("Exceptions", "exceptions"),
            ("Effective Date", "date")
        ],
        "property": [
            ("Seller", "seller"), ("Buyer", "buyer"), ("Property", "property"),
            ("Agreed Price", "price"), ("Payment Terms", "payment"), ("Agreement Date", "date"),
            ("Possession Date", "possession"), ("Documents / Records", "documents")
        ],
        "partnership": [
            ("Partners", "partners"), ("Business Name", "business"), ("Business Purpose", "purpose"),
            ("Capital Contributions", "capital"), ("Profit / Loss Sharing", "profit"),
            ("Roles", "roles"), ("Duration", "duration"), ("Effective Date", "date")
        ],
        "notice": [
            ("Sender", "sender"), ("Recipient", "recipient"), ("Sender Address", "sender_address"),
            ("Recipient Address", "recipient_address"), ("Subject", "subject"), ("Facts", "facts"),
            ("Demand", "demand"), ("Response Deadline", "deadline")
        ],
    }
    for label, key in labels[doc_type]:
        lines.append(f"{label}: {d.get(key, '') or '[Not provided]'}")

    lines += [
        "",
        "TERMS AND ACKNOWLEDGEMENT",
        "1. The parties should review all information and terms before using this draft.",
        "2. Any applicable local law, registration, stamp duty, notarization, or filing requirement should be independently verified.",
        "3. The parties may add or remove clauses as appropriate to their circumstances.",
        "",
        "SIGNATURES",
        "Party 1: __________________________    Date: ______________",
        "Party 2: __________________________    Date: ______________",
        "",
        "LEGAL DISCLAIMER",
        "This draft is for educational and informational purposes only and is not legal advice."
    ]
    return "\n".join(lines)

@app.route("/")
def index():
    return render_template("index.html", document_types=DOCUMENT_TYPES)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, email, password = request.form["name"].strip(), request.form["email"].strip().lower(), request.form["password"]
        if len(password) < 6:
            flash("Password must be at least 6 characters.")
            return redirect(url_for("register"))
        try:
            conn = db()
            conn.execute("INSERT INTO users(name,email,password,created_at) VALUES(?,?,?,?)",
                         (name, email, generate_password_hash(password), datetime.utcnow().isoformat()))
            conn.commit()
            conn.close()
            flash("Account created. Please log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email is already registered.")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email, password = request.form["email"].strip().lower(), request.form["password"]
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    conn = db()
    docs = conn.execute("SELECT * FROM documents WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    conn.close()
    return render_template("dashboard.html", docs=docs, document_types=DOCUMENT_TYPES)

@app.route("/generate/<doc_type>", methods=["GET", "POST"])
@login_required
def generate(doc_type):
    if doc_type not in DOCUMENT_TYPES:
        return "Unknown document type", 404
    if request.method == "POST":
        data = {k: request.form.get(k, "").strip() for k, _ in FIELDS[doc_type]}
        content = generate_with_ai(doc_type, data)
        conn = db()
        cur = conn.execute(
            "INSERT INTO documents(user_id,doc_type,title,content,created_at) VALUES(?,?,?,?,?)",
            (session["user_id"], doc_type, DOCUMENT_TYPES[doc_type], content, datetime.utcnow().isoformat())
        )
        doc_id = cur.lastrowid
        conn.commit()
        conn.close()
        return redirect(url_for("view_document", doc_id=doc_id))
    return render_template("generate.html", doc_type=doc_type, title=DOCUMENT_TYPES[doc_type], fields=FIELDS[doc_type])

@app.route("/document/<int:doc_id>")
@login_required
def view_document(doc_id):
    conn = db()
    doc = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (doc_id, session["user_id"])).fetchone()
    conn.close()
    if not doc:
        return "Document not found", 404
    return render_template("document.html", doc=doc)

@app.route("/document/<int:doc_id>/delete", methods=["POST"])
@login_required
def delete_document(doc_id):
    conn = db()
    conn.execute("DELETE FROM documents WHERE id=? AND user_id=?", (doc_id, session["user_id"]))
    conn.commit()
    conn.close()
    return redirect(url_for("dashboard"))

@app.route("/document/<int:doc_id>/pdf")
@login_required
def pdf(doc_id):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.enums import TA_CENTER
    from xml.sax.saxutils import escape

    conn = db()
    doc = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (doc_id, session["user_id"])).fetchone()
    conn.close()
    if not doc:
        return "Document not found", 404

    buf = BytesIO()
    pdf_doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=45, leftMargin=45, topMargin=45, bottomMargin=45)
    styles = getSampleStyleSheet()
    title_style = styles["Title"]
    title_style.alignment = TA_CENTER
    story = [Paragraph(escape(doc["title"]), title_style), Spacer(1, 18)]
    for p in doc["content"].splitlines():
        story.append(Paragraph(escape(p) if p else "&nbsp;", styles["BodyText"]))
        story.append(Spacer(1, 7))
    pdf_doc.build(story)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="legal-ease-document.pdf", mimetype="application/pdf")

@app.route("/document/<int:doc_id>/docx")
@login_required
def docx(doc_id):
    from docx import Document
    from docx.shared import Pt

    conn = db()
    doc = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (doc_id, session["user_id"])).fetchone()
    conn.close()
    if not doc:
        return "Document not found", 404

    out = BytesIO()
    word = Document()
    heading = word.add_heading(doc["title"], 0)
    for line in doc["content"].splitlines():
        p = word.add_paragraph(line)
        for run in p.runs:
            run.font.size = Pt(11)
    word.save(out)
    out.seek(0)
    return send_file(out, as_attachment=True, download_name="legal-ease-document.docx",
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

init_db()

if __name__ == "__main__":
    app.run(debug=True)
