# Legal Ease — AI-Powered Legal Document Generator

A college project that creates editable legal-document drafts from simple user inputs.

## Features
- Registration and login
- SQLite database
- 8 document types
- AI-assisted drafting when an API key is configured
- Template fallback when AI is unavailable
- Document history
- PDF and DOCX export
- Legal disclaimer
- Responsive UI

## Document types
1. Rental Agreement
2. Employment Agreement
3. Loan Agreement
4. Affidavit
5. NDA
6. Property Agreement
7. Business Partnership Agreement
8. Legal Notice

## Run locally

### 1. Create virtual environment
Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

Linux/macOS:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment
Copy `.env.example` to `.env`.

For AI generation, add your own API key:
```env
OPENAI_API_KEY=your-key
OPENAI_MODEL=gpt-5.6-luna
```

If no key is supplied, the application uses its built-in template generator.

### 4. Start
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Important
This project generates drafts for educational/informational use. It is not a substitute for advice from a qualified lawyer. Legal requirements vary by jurisdiction and document type.
